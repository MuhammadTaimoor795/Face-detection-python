import cv2 # open cv
import numpy as np # numberical calculation
from os import listdir #jab kisi directiry sa data fatch krna ho
from os.path import isfile,join

data_path='C:/Users/Muhammad Taimoor/Downloads/faces/'
onlyfiles =[f for f in listdir(data_path) if isfile(join(data_path,f))]

Training_Data,Labels=[], []

for i, files in enumerate(onlyfiles): # for iteration
    image_path=data_path+onlyfiles[i]
    images=cv2.imread(image_path,cv2.IMREAD_GRAYSCALE) #read iamges in grayscale
    Training_Data.append(np.asarray(images,dtype=np.uint8))
    Labels.append(i)

Labels =np.asarray(Labels, dtype=np.int32)

model =cv2.face.LBPHFaceRecognizer_create()

model.train(np.asarray(Training_Data),np.asarray(Labels))
print('Train Training compplete !!!!!!')